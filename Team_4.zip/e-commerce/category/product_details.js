// product_details.js

document.addEventListener('DOMContentLoaded', () => {
    const productDetailsContainer = document.getElementById('product-details-container');
    const urlParams = new URLSearchParams(window.location.search);
    const productName = urlParams.get('product');

    if (productName) {
        displayProductDetails(productName);
    }

    function displayProductDetails(productName) {
        const productDetails = getProductDetails(productName);
        productDetailsContainer.innerHTML = `
            <div class="product-slider">
                <div class="product-images">
                    ${generateProductImages(productDetails.images)}
                </div>
                <div class="slider-arrow prev" onclick="prevSlide()">&#10094;</div>
                <div class="slider-arrow next" onclick="nextSlide()">&#10095;</div>
            </div>
            <h2>${productDetails.name}</h2>
            <div class="rating-section">
                <span class="rating">${generateStarRating(productDetails.rating.value)}</span>
                <span>${productDetails.rating.value} (${productDetails.rating.number} ratings)</span>
            </div>
            <div class="specification-section">
                <h3>Specifications</h3>
                ${generateSpecifications(productDetails.specifications)}
            </div>
            <div class="reviews">
                <h3>Customer Reviews</h3>
                ${generateReviews(productDetails.reviews)}
            </div>
            <div class="product-info">
                <div class="product-info-item">Purchased by ${productDetails.purchasedCount} people</div>
                <div class="product-info-item">Rated by ${productDetails.rating.number} people</div>
            </div>
            <a class="cart-button" href="REVIEW/review.html" >ADD REVIEWS</a>
        `;
    }

    function generateProductImages(images) {
        return images.map(image => `<img src="${image}" alt="Product Image" class="product-image">`).join('');
    }

    window.nextSlide = function() {
        const productImages = document.querySelector('.product-images');
        productImages.style.transition = 'transform 0.5s ease-in-out';
        productImages.style.transform = `translateX(-${productImages.firstElementChild.clientWidth}px)`;
        setTimeout(() => {
            productImages.style.transition = 'none';
            productImages.style.transform = 'translateX(0)';
            productImages.appendChild(productImages.firstElementChild);
        }, 500);
    }

    window.prevSlide = function() {
        const productImages = document.querySelector('.product-images');
        const lastImage = productImages.lastElementChild.cloneNode(true);
        productImages.insertBefore(lastImage, productImages.firstElementChild);
        productImages.style.transition = 'none';
        productImages.style.transform = `translateX(-${productImages.firstElementChild.clientWidth}px)`;
        setTimeout(() => {
            productImages.style.transition = 'transform 0.5s ease-in-out';
            productImages.style.transform = 'translateX(0)';
        }, 0);
    }

    function generateStarRating(rating) {
        const starsTotal = 5;
        const starPercentage = (rating / starsTotal) * 100;
        const starPercentageRounded = `${Math.round(starPercentage / 10) * 10}%`;
        return `
            <div class="stars-outer">
                <div class="stars-inner" style="width: ${starPercentageRounded};"></div>
            </div>
        `;
    }

    function generateReviews(reviews) {
        return reviews.map((review, index) => `
            <div class="review" id="review-${index + 1}">
                <div class="rating">${generateStarRating(review.rating)}</div>
                <p>${review.comment}</p>
            </div>
        `).join('');
    }

    function generateSpecifications(specifications) {
        return specifications.map((specification, index) => `
            <div class="specification" id="specification-${index + 1}">${specification}</div>
        `).join('');
    }

    function getProductDetails(productName) {
        // Replace this with actual data or API calls
        switch (productName) {
            case 'Samsung Galaxy S21':
                return {
                    name: 'Samsung Galaxy S21',
                    images: ['images/Samsung_mob.jpg','images/Samsung_mob.jpg','images/Samsung_mob.jpg','images/Samsung_mob.jpg',],
                    rating: {
                        value: 4.3,
                        number: 150,
                    },
                    reviews: [
                        { rating: 4, comment: 'Great phone, excellent camera!' },
                        { rating: 5, comment: 'Fast delivery and good packaging.' },
                        // Add more reviews as needed
                    ],
                    specifications: [
                        'Display: 6.2 inches, 1080 x 2400 pixels',
                        'Processor: Exynos 2100 (Global) - Snapdragon 888 (USA/China)',
                        'RAM: 8GB',
                        'Storage: 128GB, expandable up to 1TB',
                        'Camera: Triple rear (12MP + 12MP + 64MP), 10MP front',
                        'Battery: 4000mAh',
                        // Add more specifications as needed
                    ],
                    purchasedCount: 200,
                };
            // Add more cases for other products
            default:
                return {};
        }
    }
});
