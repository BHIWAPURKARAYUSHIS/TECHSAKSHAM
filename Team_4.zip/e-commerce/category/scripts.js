// scripts.js

document.addEventListener('DOMContentLoaded', () => {
    const categoryList = document.getElementById('category-list');
    const productContainer = document.getElementById('product-container');

    // Function to load products based on category
    function loadProducts(category) {
        const products = getProducts(category);
        productContainer.innerHTML = '';

        products.forEach((product) => {
            const productElement = document.createElement('div');
            productElement.className = 'product';
            productElement.innerHTML = `
                <img src="${product.image}" alt="${product.name}">
                <h3>${product.name}</h3>
                <p>${product.description}</p>
                <p>Price: $${product.price}</p>
                <a href="product_details.html?product=${encodeURIComponent(product.name)}" class="details-button" data-product="${product.name}">View Details</a>
  

            `;
            productContainer.appendChild(productElement);
        });

        addDetailsButtonListeners();
    }

    // Function to add click listeners to "View Details" buttons
    function addDetailsButtonListeners() {
        const detailsButtons = document.querySelectorAll('.details-button');

        detailsButtons.forEach((button) => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const productName = e.target.dataset.product;
                window.location.href = `product_details.html?product=${encodeURIComponent(productName)}`;
            });
        });
    }

    // Event listener for category clicks
    categoryList.addEventListener('click', (e) => {
        if (e.target.tagName === 'LI') {
            const selectedCategory = e.target.textContent;
            loadProducts(selectedCategory);
            highlightCategory(selectedCategory);
        }
    });

    // Function to highlight the selected category
    function highlightCategory(selectedCategory) {
        const categoryItems = categoryList.getElementsByTagName('li');

        for (const item of categoryItems) {
            if (item.textContent === selectedCategory) {
                item.style.backgroundColor = '#555';
                item.style.color = '#fff';
            } else {
                item.style.backgroundColor = 'transparent';
                item.style.color = '#fff';
            }
        }
    }

    // Function to get products based on category
    function getProducts(category) {
        // Example data with more images
        switch (category) {
            case 'Mobiles':
                return [
                    { name: 'Samsung Galaxy S21', description: '(6.8-inch) Dynamic AMOLED 2X Display, WQHD+ resolution with 3200 X 1440 pixels resolution color, 515 PPI with 16M color.', price: 64999, image: 'images/Samsung_mob.jpg' },
                    { name: 'Apple iPhone 13 (128GB) - Pink', description: 'Advanced dual-camera system with 12MP Wide and Ultra Wide cameras; Photographic Styles, Smart HDR 4', price: 52999, image: 'images/iphone_12.jpg' },
                    { name: 'OnePlus Nord CE 3 5G (Aqua Surge, 8GB RAM, 128GB Storage)', description: 'Display: 6.7 Inches; 120 Hz AMOLED FHD+, Resolution: 2412 x 1080 pixels; HDR 10+, sRGB, 10-bit Color Depth', price: 24999, image: 'images/OnePlus_mob.jpg' },
                    { name: 'vivo Y17s (Forest Green, 4GB RAM, 64GB Storage)', description: 'Display: 16.55 cm (6.56" inch) LCD Capacitive multi-touch display, 60Hz refresh rate, 269 ppi, Memory & SIM: 4GB RAM | 64GB internal memory.', price: 10499, image: 'images/vivo_mob.jpg' },
                    { name: 'Oppo Reno10 Pro 5G (Glossy Purple, 12GB RAM, 256GB Storage)', description: 'Android 13, Color, OS 13.16.7 inch FHD+ 120Hz Display Qualcomm Snapdragon 778G(SDM778G) Processor.', price: 34979.99 , image: 'images/oppo_mob.jpg' },
                    { name: 'POCO C51 (Royal Blue, 6GB RAM, 128GB Storage)', description: 'Powerful MediaTek G36 octa-core CPU ; clocked at up to 2.2 GHz | 11GB of RAM including 5GB virtual.', price: 5999, image: 'images/poco_mob.jpg' },
                    { name: 'Redmi Note 13 Pro+ 5G (Fusion Black, 12GB RAM, 256GB Storage)', description: 'Redmi Note 13 Pro+ 5G (Fusion Black, 12GB RAM, 256GB Storage) Product Dimensions:16.14 x 7.42 x 0.89 cm; 204.5 Grams.', price: 33810.00, image: 'images/Redmi_mob.jpg' },
                    { name: 'TECNO POP 8 (Mystery White,(8GB*+64GB)|90Hz Punch Hole Display ', description: 'TECNO POP 8 (Mystery White,(8GB*+64GB)|90Hz Punch Hole Display Side Fingerprint Sensor,10W Type-C', price: 6599, image: 'images/Tecno_mob.jpg' },
                ];
            case 'Laptops':
                return [
                    { name: 'Apple MacBook', description: 'Apple MacBook Air Laptop M1 chip, 13.3-inch/33.74 cm Retina Display, 8GB RAM, 256GB SSD Storage, Backlit Keyboard FaceTime HD Camera; Silver.', price: 77990, image:'images/Apple_MacBook.jpg' },
                    { name: 'Dell XPS 9530', description: 'Intel Evo Platform Powered by Intel Core i7-13700H Processor/32GB DDR5/1TB SSD/NVIDIA RTX 4050 6GB GDDR6/15.6"(39.62cm) OLED.', price: 279490, image:'images/dell_lap.jpg' },
                    { name: 'Samsung Galaxy Book2 (NP750)', description: 'Intel 12th Gen core i5 39.6cm (15.6") FHD Thin & Light Laptop (8 GB/512 GB/Windows 11/MS Office /Backlit Keyboard.', price: 49990, image: 'images/Samsung_lap.jpg' },
                    { name: 'Lenovo ThinkPad X1 Carbon', description: '(Refurbished) Lenovo ThinkPad 8th Gen Intel Core i5 Thin & Light Touchscreen FHD Laptop (8 GB DDR4 RAM/256 GB SSD.', price: 20999, image: 'images/Lenovo ThinkPad X1 Carbon.jpg' },{ name: 'HP Victus Gaming Laptop', description: 'HP Victus Gaming Laptop, AMD Ryzen 7 7840HS AI Powered, 6GB RTX 3050 GPU, 16.1-inch (40.9 cm).', price: 81990, image: 'images/HP_lap.jpg' },{ name: 'ASUS Vivivook Pro 15', description: 'AMD Ryzen 7 5800H, 15.6"(39.6 cm) HD, Thin & Light Laptop (16GB/512GB SSD/4GB NVIDIA GeForce RTX 3050/Windows 11.', price: 73990, image: 'images/ASUS_vivobook.jpg' },
                    { name: 'Acer one 14 Business Laptop', description: ' AMD Ryzen 3 3250U Processor (8GB RAM/256GB SSD/AMD Radeon Graphics/Windows 11 Home) .', price: 25990, image: 'images/acer_lap.jpg' },
                    { name: 'TECNO MEGABOOK T1', description: 'Intel Core 11th Gen i3 Processor (8GB RAM/ 512GB SSD Storage), 15.6-Inch (39.62 CM) Eye Comfort disply.', price: 23990, image: 'images/tecno_lap.jpg' },
                ];
            case 'Televisions':
                return [
                    { name: 'Samsung ', description: 'QLED TV with Quantum Dot technology for vibrant colors.', price: 1299.99, image: 'images/Samsung_Neo_TV.jpg' },
                    { name: 'Redmi', description: 'Redmi 80 cm (32 inches) F Series HD Ready Smart LED Fire TV L32R8-FVIN (Black).', price: 1999.99, image: 'images/Redmi_TV.jpg' },
                    { name: 'LG', description: 'LG 81.28 cm (32 inch) HD LED Smart TV, 32LM562BPTA.', price: 1499.99, image: 'images/LG_TV.jpg' },
                    { name: 'VU', description: 'Vu 85 inches Masterpiece QLED 4K TV 85QV.', price: 1499.99, image: 'images/VU_TV.jpg' }, 
                    { name: 'Sony', description: 'Sony Bravia 164 cm (65 inches) 4K Ultra HD Smart LED Google TV KD-65X82L (Black).', price: 1499.99, image: 'images/Sony_TV.jpg' },
                    { name: 'Kevin', description: 'Kevin 32 Series 80 cm (32 inch) HD Ready LED TV with Advanced HRDD Technology (2021 model).', price: 1499.99, image: 'images/Kevin_TV.jpg' },
                    { name: 'Xiaomi', description: 'Xiaomi Smart TV 5A Pro 32 (80 cm).', price: 1499.99, image: 'images/Xiaomi_TV.jpg' },
                    { name: 'Samsung', description: 'Samsung 80 cm (32 inches) HD Ready Smart LED TV UA32T4380AKXXL (Glossy Black).', price: 1499.99, image: 'images/Samsung_TV.jpg' },
                ];
            case 'Headphones':
                return [
                    { name: 'Sony', description: 'Sony WH-CH520, Wireless On-Ear Bluetooth Headphones with Mic, Upto 50 Hours Playtime, DSEE Upscale, Multipoint Connectivity.', price:4490, image: 'images/Sony_Head.jpg' },
                    { name: 'Boat', description: 'boAt Nirvana 751 ANC Hybrid Active Noise Cancelling Bluetooth Wireless Over Ear Headphones with Up to 65H Playtime, ASAP Charge, Ambient Sound Mode.', price: 4490, image: 'images/Boat_Head.jpg' },
                    { name: 'Samsung',description: 'Samsung Level On PRO Wireless Noise Cancelling Headphones with Microphone and UHQ Audio.', price: 799.99, image: 'images/Samsung_Head.jpg' },
                    { name: 'JBL', description: 'JBL Tune 760NC, Over Ear ANC Wireless Headphones with Mic, up to 50 Hours Playtime, Pure Bass, Google Fast Pair, Dual Pairing.', price: 5499, image: 'images/JBL_Head.jpg' },
                    { name: 'Zebronics', description: 'ZEBRONICS Zeb Dynamic Bluetooth Wireless Headphone.', price: 799.99, image: 'images/Zebronics_Head.jpg' },
                    { name: 'Xiaomi', description: 'Xiaomi mi Headphones Black Headphone Black and Gold (TDSEJ02JY) .5mm to 6.3 adapter(1);Microfiber drawstring bag(1)^Hard Carrying case(.', price: 799.99, image: 'images/mi_Head.jpg' },
                    { name: 'Noise', description: 'Noise Two Wireless On-Ear Headphones with 50 Hours Playtime, DSEE Upscale, Multipoint Connectivity/Dual Pairing.', price: 799.99, image: 'images/Noise_Head.jpg' },  { name: 'Beats', description: 'Beats Studio Pro Wireless Headphones Class 1 Bluetooth, Active Noise Cancelling, 22 Hours of Listening Time.', price: 799.99, image: 'images/Beats_Head.jpg' },
                ];
            case 'Smart Band':
                    return [
                        { name: 'Samsung ', description: 'Samsung Galaxy Watch 5 LTE (44mm) Smart Watch 44Mm 40Mm Case Screen Protector For Mobile, For Men And Women Full Protection Cover', price: 1299.99, image: 'images/Samsung_Band.jpg' },
                        { name: 'Noise', description: 'Noise ColorFit Fitness Band Bluetooth Calling, 1.69" TFT Display, SpO2, 100 Sports Mode with Auto Detection, Upto 7 Days Battery.', price: 1999.99, image: 'images/Noise_Band.jpg' },
                        { name: 'Apple', description: 'Apple Watch Series 9 [GPS 45mm] Smartwatch with Midnight Aluminum Case with Midnight Sport Band M/L. Fitness Tracker.', price: 1499.99, image: 'images/Apple_Band.jpg' },
                        { name: 'OnePlus', description: 'OnePlus Band  (Black Strap, Size : Regular) MARVIK ERGONOMIC DESIGN - Accurate cutting holes that fit most wrists; numerous extra holes that can be lengthened.', price: 2799.00, image: 'images/OnePlus_Band.jpg' }, 
                        { name: 'Redmi', description: 'VENTAGE M5 Smart Watch Fitness Tracker Band  (Black Strap, Size : Free) Bracelet Watch, Smart Fitness Band with Heart Rate Sensor Compatible All Androids iOS Phone (Black).', price: 1499.99, image: 'images/Redmi_Band.jpg' },
                        { name: 'Jio', description:  'Jio J2 Smartband - Black (1.05-HWD0B0B) Button Touch, Colour Display (Black) Step count monitoring function with target completion reminder and Calories burn tracking Working time up to 7-10 days of normal usage.', price: 1499.99, image: 'images/Jio_Band.jpg' },
                        { name: 'AYL', description: 'mi Smart Watch for Kids Men Boys Girls Women ID116 Plus 2023 Latest for Android and iOS Phones IP68 Waterproof Activity Tracker with Touch Color Screen Sleep.', price: 899.00, image: 'images/AYL_spe.jpg' },
                        { name: 'Titan', description: 'Reflex Play- Smart Watch with Black Strap, Amoled Display, Health Suite, In-Built Games, & Period Tracker.', price: 3695.00, image: 'images/titan_band.jpg' },
                        ];       
                case 'Speakers':
                  return [
                       { name: 'Sony', description: 'Sony Srs-Xb13 Wireless Extra Bass Portable Compact Bluetooth Speaker with 16 Hours Battery LifeType-C, Ip67 Waterproof Dustproof, with Mic, Loud Audio for Phone Calls', price: 1299.99, image: 'images/Sony_spe.jpg' },
                       { name: 'boAt', description: 'boAt Stone 1450 Portable Wireless Speaker with 40W RMS Signature Sound.', price: 1999.99, image: 'images/Boat_spe.jpg' },
                       { name: 'Amazon Echo dot', description: 'Echo Dot (5th Gen) | Smart speaker with Bigger sound.Motion Detection, Temperature Sensor, Alexa and Bluetooth| Blue', price: 1499.99, image: 'images/Echo_spe.jpg' },
                       { name: 'Creative', description: 'Creative Pebble Pro Minimalist 2.0 USB-C Computer Speakers with Bluetooth 5.3 8W RMS with 16W Peak Power, USB-A Converter Included (Black)', price: 1499.99, image: 'images/Creative_spe.jpg' }, 
                       { name: 'Philips', description: 'Philips Convertible Soundbar MMS8085B/94 2.1 Channel 80W.', price: 1499.99, image: 'images/philips_spe.jpg' },
                       { name: 'Barrel', description: 'Barrel wireless bluetooth Speaker.', price: 14878.76, image: 'images/Barrel_spe.jpg' },
                       { name: 'Marshall', description: 'KILBURN II BLACK AND BRASS, offers 20+ hours of portable playtime on a single charge.This stout-hearted hero produces a larger than life multi-directional sound that will immerse you in your music, indoors or out.Kilburn II comes equipped with Bluetooth',price: 31999.00 ,image:'images/marshall_spe.jpg' },
                       { name: 'onn', description: 'onn. AC Powered Computer Speakers with Volume and Bass Controls.', price: 1499.99, image: 'images/onn_spe.jpg' },
                    ];       

            default:
                return [];
        }
    }
});

// Updated script for product details page
document.addEventListener('DOMContentLoaded', () => {
    const productDetailsContainer = document.getElementById('product-details-container');
    const urlParams = new URLSearchParams(window.location.search);
    const productName = urlParams.get('product');

    if (productName) {
        displayProductDetails(productName);
    }

    function displayProductDetails(productName) {
        const productDetails = getProductDetails(productName);
        productDetailsContainer.innerHTML = `
            <img src="${productDetails.image}" alt="${productDetails.name}">
            <h2>${productDetails.name}</h2>
            <p>${productDetails.description}</p>
            <p>Price: $${productDetails.price}</p>
            <h3>Specifications</h3>
            <ul>
                <li>Brand: ${productDetails.brand}</li>
                <li>Model: ${productDetails.model}</li>
                <li>Color: ${productDetails.color}</li>
            </ul>
            <h3>Reviews</h3>
            <p>No reviews yet.</p>
        `;
    }

    function getProductDetails(productName) {
        // Replace this with actual data or API calls
        switch (productName) {
            case 'Samsung Galaxy S21':
                return {
                    name: 'Samsung Galaxy S21',
                    description: 'Powerful smartphone with high-end features.',
                    price: 64999,
                    brand: 'Samsung',
                    model: 'Galaxy S21',
                    color: 'Phantom Silver',
                    image: 'images/Samsung_mob.jpg',
                };
            // Add more cases for other products
            default:
                return {};
        }
    }
});


