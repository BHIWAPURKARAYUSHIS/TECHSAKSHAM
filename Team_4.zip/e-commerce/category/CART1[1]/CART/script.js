let cartTotal = 0;

function addToCart() {
    cartTotal++;
    document.getElementById('cart-total').innerText = cartTotal;
}
